package wpi.nets.lightsensorlog;

// Re-implementation of TinyOS tool, license is as follows

/*									tab:4
 * "Copyright (c) 2000-2005 The Regents of the University  of California.  
 * All rights reserved.
 *
 * Permission to use, copy, modify, and distribute this software and
 * its documentation for any purpose, without fee, and without written
 * agreement is hereby granted, provided that the above copyright
 * notice, the following two paragraphs and the author appear in all
 * copies of this software.
 * 
 * IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY
 * PARTY FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
 * DAMAGES ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS
 * DOCUMENTATION, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN
 * ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * THE UNIVERSITY OF CALIFORNIA SPECIFICALLY DISCLAIMS ANY WARRANTIES,
 * INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY
 * AND FITNESS FOR A PARTICULAR PURPOSE.  THE SOFTWARE PROVIDED HEREUNDER IS
 * ON AN "AS IS" BASIS, AND THE UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO
 * PROVIDE MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS."
 *
 * Copyright (c) 2002-2005 Intel Corporation
 * All rights reserved.
 *
 * This file is distributed under the terms in the attached INTEL-LICENSE     
 * file. If you do not find these files, copies can be found by writing to
 * Intel Research Berkeley, 2150 Shattuck Avenue, Suite 1300, Berkeley, CA, 
 * 94704.  Attention:  Intel License Inquiry.
 */
/* Authors:	Phil Levis <pal@cs.berkeley.edu>
 * Date:        December 1 2005
 * Desc:        Generic Message reader
 *               
 */

import java.util.*;
import java.util.concurrent.LinkedBlockingQueue;

import net.tinyos.message.*;
import net.tinyos.packet.*;
import net.tinyos.util.*;

public class log implements net.tinyos.message.MessageListener {
	
private int lastRed = 0;
private int lastGreen = 0;
public volatile int redAboves = 0;
public volatile int greenAboves = 0;
public volatile LinkedBlockingQueue<String> states = new LinkedBlockingQueue<String>();

private MoteIF moteIF;
  
  public log(String source) throws Exception {
    if (source != null) {
      moteIF = new MoteIF(BuildSource.makePhoenix(source, PrintStreamMessenger.err));
    }
    else {
      moteIF = new MoteIF(BuildSource.makePhoenix(PrintStreamMessenger.err));
    }
  }

  public void start() {
	  Timer t = new Timer();
	  long delay = 60*1000; //60 seconds
	  t.schedule(new Task(this), delay);
  }
  
  public void messageReceived(int to, Message message) {
    LightSensorMsg m = (LightSensorMsg)message;
	int g = m.get_green();
	int r = m.get_red();

	if((this.lastGreen == 0) && (g == 1)){
			this.states.offer("Green went above threshold");
			this.greenAboves += 1;
	} else if((this.lastGreen == 1) && (g == 0)){
		this.states.offer("Green went below threshold");
	}

	if((this.lastRed == 0) && (r == 1)){
		this.states.offer("Red went above threshold");
		this.redAboves += 1;
	} else if((this.lastRed == 1) && (r == 0)){
		this.states.offer("Red went below threshold");
	}
		
	this.lastGreen = g;
	this.lastRed = r;
  }

  private void addMsgType(Message msg) {
    moteIF.registerListener(msg, this);
  }
  
  public static void main(String[] args) throws Exception {
    String source = null;
    Vector v = new Vector();
    
    try {
    	Object packet = new LightSensorMsg();
	    LightSensorMsg msg = (LightSensorMsg)packet;
	    if (msg.amType() < 0) {
		System.err.println("LightSensorMsg does not have an AM type - ignored");
	    } else {
		v.addElement(msg);
	    }
	} catch (Exception e) {
	    System.err.println(e);
	} 

    log mr = new log(source);
    Enumeration msgs = v.elements();
    while (msgs.hasMoreElements()) {
      Message m = (Message)msgs.nextElement();
      mr.addMsgType(m);
    }
    mr.start();
  }
  
  public class Task extends TimerTask {
	  	private log l;
	  	
		private int reds, greens;
		
		public Task(log lg) {
			this.l = lg;
		}

		@Override
		public void run() {
			while(l.states.peek() != null){
				System.out.println(l.states.poll());
			}
			this.greens = l.greenAboves;
			this.reds = l.redAboves;
			System.out.println("Number of times red was above threshold: " + this.reds);
			System.out.println("Number of times green was above threshold: " + this.greens);
			System.exit(0);
		}

	}

}
